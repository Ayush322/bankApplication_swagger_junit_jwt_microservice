package com.fis.bankApplicationMicroservices.model;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

import com.fis.bankApplicationMicroservices.model.BankCustomer;
public class BankCustomerTest {
	
	BankCustomer check = new BankCustomer();
	
 
	@Test
	void setAccountIdTest() {
		check.setAcctID(202300001);
		assertEquals(202300001, check.getAcctID());
	}
 
	@Test
	void setCustomerIdTest() {
		check.setCustName("Ayush");
		assertEquals("Ayush", check.getCustName());
	}
	
	@Test
	void setCityTest() {
		check.setCity("Gorakhpur");
		assertEquals("Bangalore", check.getCity());
	}
	
	@Test
	void setPhoneTest() {
		check.setPhoneNo(895784032);
		assertEquals(895784032, check.getPhoneNo());
	}
 



}
