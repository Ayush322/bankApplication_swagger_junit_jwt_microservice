package com.fis.bankApplicationMicroservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankApplicationMicroservices.exception.ErrorResponse;
import com.fis.bankApplicationMicroservices.model.BankCustomer;
import com.fis.bankApplicationMicroservices.service.CustomerService;

@RestController
public class CustomerDataController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private AccountDataController accountDataController;

	@PostMapping("/customer")
	public void createCustomer(@RequestBody BankCustomer bankCustomer) {
		//call customer service to create the customer
		customerService.createCustomer(bankCustomer);
		// call accountController to create an account for the customer with a 0 balance and active status
		accountDataController.createAccount(bankCustomer.getAcctID(), 0, "Active");
	}

	@GetMapping("/customer/{acctID}")
// Handling the exception with responseEntity using
		public ResponseEntity<?> getCustomerInfo(@PathVariable int acctID) {
	        BankCustomer user = customerService.getCustomerInfo(acctID);
	        if (user == null) {
	          ErrorResponse errorResponse = new ErrorResponse();
	          errorResponse.setMessage("Record not found");
	          return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	         }
	       return new ResponseEntity<>(user, HttpStatus.OK); 
	    }    
	

	@DeleteMapping("/customer/{acctID}")
	public void deleteCustomer(@PathVariable int acctID) {
		// delete the account details of the customer
		customerService.deleteCustomer(acctID);
	}
	
	

}
