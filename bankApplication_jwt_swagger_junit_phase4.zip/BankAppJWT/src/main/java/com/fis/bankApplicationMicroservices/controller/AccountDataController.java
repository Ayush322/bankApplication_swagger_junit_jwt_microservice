package com.fis.bankApplicationMicroservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankApplicationMicroservices.exception.UserNotFound;
import com.fis.bankApplicationMicroservices.model.Accounts;
import com.fis.bankApplicationMicroservices.model.Logger;
import com.fis.bankApplicationMicroservices.service.AccountService;

@RestController
public class AccountDataController {
	@Autowired
	private AccountService accountService;
	@Autowired
	private LoggerDataController loggerDataController;

	// createAccount happens upon createCustomer
	public void createAccount(int acctID, int balance, String acctStatus) {
		Accounts acct = new Accounts(acctID, balance, acctStatus);
		accountService.createAccount(acct);
	}

	// checkBalance
	@GetMapping("/account/{acctID}/balance")
	public int getBalance(@PathVariable int acctID) throws UserNotFound {
		// retrieve the account balance for the given account ID
		return accountService.getBalance(acctID);
	}

	// depositAmount
	@PutMapping("/account/{acctID}/deposit/{amount}")
	public void depositAmount(@PathVariable int acctID, @PathVariable int amount) throws UserNotFound {
		int initBal = getBalance(acctID);
		// call the depositAmount method from the 'accountService' to deposit the specified amount
		accountService.depositAmount(acctID, amount);
		// create a new logger instance to log deposit action
		Logger logger = new Logger(acctID, "Deposited", "Success", initBal, initBal + amount);
		
		loggerDataController.addLog(logger);
	}

	// withdrawAmount
	@PutMapping("/account/{acctID}/withdraw/{amount}")
	public void withdrawAmount(@PathVariable int acctID, @PathVariable int amount) throws UserNotFound {
		// get the initial balance of the account
		int initBal = getBalance(acctID);
		// perform withdrawl operation
		accountService.withdrawAmount(acctID, amount);
		// create a log entry of withdrawl operation
		Logger logger = new Logger(acctID, "Withdrawn", "Success", initBal, initBal - amount);
		loggerDataController.addLog(logger);
	}

	// transferAmount
	@PutMapping("/account/{acctID}/transfer/{destAcctID}/{amount}")
	public void transferAmount(@PathVariable int acctID, @PathVariable int destAcctID, @PathVariable int amount) throws UserNotFound {
		// get the intial balance of sender and receiver account
		int initBalSender = getBalance(acctID);
		int initBalReceiver = getBalance(destAcctID);
		// perform transfer operation
		accountService.transferAmount(acctID, destAcctID, amount);
		// create a log enteries for sender and receiver
		Logger loggerSender = new Logger(acctID, "Transferred", "Success", initBalSender, initBalSender - amount);
		loggerDataController.addLog(loggerSender);
		Logger loggerReceiver = new Logger(destAcctID, "Received", "Success", initBalReceiver,
				initBalReceiver + amount);
		loggerDataController.addLog(loggerReceiver);
	}

	// deleteAccount
	@DeleteMapping("/account/{acctID}")
	public String deleteAccount(@PathVariable int acctID) {
		// call the accountservice to delete the account
		accountService.deleteAccount(acctID);
		// log the account deletion in the loggercontroller
		loggerDataController.deleteLog(acctID);
		return "Account deleted successfully...!";
	}

	// getAccountInfo
	@GetMapping("/account/{acctID}")
	public Accounts getAccountInfo(@PathVariable int acctID) throws UserNotFound {
		// call the accountservice to get the account information
		return accountService.getAccountInfo(acctID);
	}

}
