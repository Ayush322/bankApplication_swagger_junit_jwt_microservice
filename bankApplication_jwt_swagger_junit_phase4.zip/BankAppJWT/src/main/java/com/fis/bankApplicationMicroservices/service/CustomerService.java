package com.fis.bankApplicationMicroservices.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankApplicationMicroservices.model.BankCustomer;
import com.fis.bankApplicationMicroservices.repository.CustomerRepo;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepo customerRepo;
// this method is used to create the customer
	public void createCustomer(BankCustomer bankCustomer) {
		customerRepo.save(bankCustomer);
	}
// this method is used to get customer information by account ID
	public BankCustomer getCustomerInfo(int acctID) {
		return customerRepo.findById(acctID).orElse(null);
	}
// this method is used to delete the customer by account ID
	public void deleteCustomer(int acctID) {
		customerRepo.deleteById(acctID);
	}

}
