package com.fis.bankApplicationMicroservices.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankApplicationMicroservices.controller.AccountDataController;
import com.fis.bankApplicationMicroservices.exception.UserNotFound;
import com.fis.bankApplicationMicroservices.model.Accounts;
import com.fis.bankApplicationMicroservices.repository.AccountsRepo;

@Service
public class AccountService {
	@Autowired
	private AccountsRepo accountRepository;
// this method is used to create a new account
	public void createAccount(Accounts acct) {
		accountRepository.save(acct);
	}
// this method is used to retrieve account information by ID
	public Accounts getAccountInfo(int acctID) throws UserNotFound {
		Optional<Accounts> optional = accountRepository.findById(acctID);
		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new UserNotFound("Account ID is invalid...");
		}
		
		//return accountRepository.findById(acctID).orElse(null);
	}
// this method is used to delete an account by its ID
	public void deleteAccount(int acctID) {
		accountRepository.deleteById(acctID);
	}
// this method is used to get the account balance by ID
	public int getBalance(int acctID) {
		return accountRepository.findBalanceByAcctID(acctID);
	}
// this method is used to deposit the amount in customer account
	public void depositAmount(int acctID, int amount) {
		accountRepository.saveBalanceByAcctID(acctID, amount);
	}
// this method is used to withdraw the amount using account ID
	public void withdrawAmount(int acctID, int amount) {
		accountRepository.withdrawAmountByAcctID(acctID, amount);
	}
// this method is used to transfer the fund from user account to beneficiary account
	public void transferAmount(int acctID, int destAcctID, int amount) {
		accountRepository.withdrawAmountByAcctID(acctID, amount);
		accountRepository.saveBalanceByAcctID(destAcctID, amount);
	}

}
